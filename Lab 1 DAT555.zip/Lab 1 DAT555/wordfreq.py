lines = ['10  sweet  apple  tarts.']

def tokenize(lines):
    words = []
    for line in lines:
        start = 0
        end = start
        while start < len(line):
            if not line[start].isspace():
                if line[start].isalpha():
                    pass
                    #print(line[start] + " is a letter")
                elif line[start].isdigit():
                    pass
                    #print(line[start] + " is a digit")
                else:
                    pass
                    #print(line[start] + " is a symbol")
            else:
                
                words.append(line[start:end])
                start = end

            end += 1
    
    return words

print(tokenize(lines))